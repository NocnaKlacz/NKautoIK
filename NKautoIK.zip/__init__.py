bl_info = {
    "name": "NK Auto IK",
    "author": "NK",
    "version": (1, 0, 0),
    "blender": (4, 5, 0),
    "location": "View3D > Sidebar (N) > NK IK",
    "description": "Detects legs and arms in an armature (or uses bones you pick) and builds working IK controls "
                   "with automatically chosen bend direction, pole target, pole angle and joint limits",
    "category": "Rigging",
}

import math
import re

import bpy
from bpy.props import (BoolProperty, CollectionProperty, EnumProperty, FloatProperty, IntProperty,
                       PointerProperty, StringProperty)
from mathutils import Matrix, Quaternion, Vector

IK_PREFIX = "IK_"
POLE_PREFIX = "POLE_"
CON_IK = "NKIK"
CON_ROT = "NKIK_ROT"
PROP_TAG = "nkik"
PROP_LIM = "nkik_lim"
PROP_SEED = "nkik_seed"
PROP_SWITCH = "IK"
COLLECTION_NAME = "IK Controls"

# ---------------------------------------------------------------------------
# Name-based recognition
# ---------------------------------------------------------------------------

_TOKEN_RE = re.compile(r"[A-Z]?[a-z]+|[A-Z]+(?![a-z])|\d+")

ARM_TOKENS = {"arm", "forearm", "upperarm", "lowerarm", "uparm", "lowarm", "humerus", "shoulder", "shldr",
              "clavicle", "elbow", "wrist", "hand"}
LEG_TOKENS = {"leg", "thigh", "calf", "shin", "upleg", "upperleg", "lowerleg", "lowleg", "femur", "foot",
              "knee", "ankle", "tibia"}
ROOT_TOKENS = {"root", "master", "world", "ground", "origin", "trajectory", "traj", "global", "base"}


# segment roles - used to pick the right chain (upper bone, lower bone, end bone)
PROXIMAL_TOKENS = {"shoulder", "shldr", "clavicle", "pelvis", "hips", "hip", "spine", "chest", "neck", "head"}
DISTAL_TOKENS = {"hand", "foot", "toe", "toes", "wrist", "ankle", "heel", "palm", "finger"}
UPPER_TOKENS = {"thigh", "upperarm", "uparm", "upleg", "upperleg", "femur", "humerus", "upper", "up"}
LOWER_TOKENS = {"forearm", "lowerarm", "lowarm", "shin", "calf", "lowerleg", "lowleg", "tibia", "lower", "fore"}


def _tokens(name):
    return [t.lower() for t in _TOKEN_RE.findall(name.split(":")[-1])]


def role_factor(n0, n1):
    """Chain score multiplier from name roles: thigh/upper arm beat clavicle, hand/foot are never the 'upper' bone."""
    t0, t1 = set(_tokens(n0)), set(_tokens(n1))
    f = 1.0
    if t0 & PROXIMAL_TOKENS:
        f *= 0.3
    if (t0 | t1) & DISTAL_TOKENS:
        f *= 0.3
    if (t0 & UPPER_TOKENS) or (t1 & LOWER_TOKENS):
        f *= 1.5
    return f


def name_kind(names):
    arm = leg = 0
    for n in names:
        for t in _tokens(n):
            arm += t in ARM_TOKENS
            leg += t in LEG_TOKENS
    if arm and not leg:
        return "ARM"
    if leg and not arm:
        return "LEG"
    return None


def name_side(names):
    left = right = 0
    for n in names:
        ts = _tokens(n)
        left += ("left" in ts) or ("l" in ts)
        right += ("right" in ts) or ("r" in ts)
    if left > right:
        return "L"
    if right > left:
        return "R"
    return None


# ---------------------------------------------------------------------------
# Armature analysis
# ---------------------------------------------------------------------------

class Limb:
    pass


class Rig:
    pass


def _flat(v, up):
    return v - up * v.dot(up)


def _foot_direction(foot, up):
    """'Forward' direction from the foot shape (horizontal projection of the farthest foot/toe point)."""
    h0 = foot.head_local
    best, best_len = None, 0.0
    stack = [(foot, 0)]
    while stack:
        b, d = stack.pop()
        v = _flat(b.tail_local - h0, up)
        if v.length > best_len:
            best, best_len = v, v.length
        if d < 2:
            stack.extend((c, d + 1) for c in b.children)
    if best is None or best_len < 0.2 * max(foot.length, 1e-6):
        return None
    return best.normalized()


def _expected_bend(kind, a, F, up):
    """Direction the joint sticks out: knee forward, elbow backward."""
    base = F if kind == "LEG" else -F
    e = base - a * base.dot(a)
    if e.length < 0.35:
        alt = up if kind == "LEG" else -up
        e = alt - a * alt.dot(a)
    return e.normalized()


def _describe_dir(v, rig):
    f, u = v.dot(rig.F), v.dot(rig.up)
    s = v.dot(rig.up.cross(rig.F))
    return max((abs(f), "front" if f > 0 else "back"),
               (abs(u), "up" if u > 0 else "down"),
               (abs(s), "left" if s > 0 else "right"))[1]


def _manual_candidates(arm, manual):
    """Builds limb candidates from user-picked bones: dicts with kind, side, upper, lower, end."""
    cands = []
    for m in manual:
        b0, b1 = arm.bones.get(m["upper"]), arm.bones.get(m["lower"])
        b2 = arm.bones.get(m["end"]) if m["end"] else None
        if b0 is None or b1 is None:
            raise ValueError("Pick existing Upper and Lower bones for every manual limb.")
        if b1.parent is None or b1.parent.name != b0.name:
            raise ValueError("'%s' must be a direct child of '%s'." % (b1.name, b0.name))
        if m["end"] and (b2 is None or b2.parent is None or b2.parent.name != b1.name):
            raise ValueError("End bone '%s' must be a direct child of '%s'." % (m["end"], b1.name))
        c = Limb()
        c.kind, c.side, c.b0, c.b1, c.b2 = m["kind"], m["side"], b0, b1, b2
        c.names = [b0.name, b1.name] + ([b2.name] if b2 else [])
        c.score, c.total = 1.0, b0.length + b1.length
        cands.append(c)
    return cands


def analyze(obj, forward_mode="AUTO", min_bend_deg=2.0, manual=None):
    """Finds the limbs. With `manual` (list of dicts) the given bones are used instead of auto-detection."""
    arm = obj.data
    bones = list(arm.bones)
    if len(bones) < 4:
        raise ValueError("The armature has too few bones.")

    try:
        inv = obj.matrix_world.to_3x3().inverted()
    except ValueError:
        inv = Matrix.Identity(3)

    def w2a(v):
        return (inv @ Vector(v)).normalized()

    rig = Rig()
    up = w2a((0, 0, 1))
    deform = [b for b in bones if b.use_deform] or bones
    hs = [p.dot(up) for b in deform for p in (b.head_local, b.tail_local)]
    hmin, hmax = min(hs), max(hs)
    H = hmax - hmin
    if H < 1e-6:
        raise ValueError("The armature has zero height.")
    rig.up, rig.hmin, rig.H = up, hmin, H

    depth = {}

    def get_depth(b):
        d = depth.get(b.name)
        if d is None:
            d = depth[b.name] = 1 + max((get_depth(c) for c in b.children), default=0)
        return d

    for b in bones:
        get_depth(b)

    def best_child(b):
        ks = list(b.children)
        return max(ks, key=lambda c: (depth[c.name], c.length)) if ks else None

    # --- candidates: chains (upper bone, lower bone, end bone) ---
    cands = []
    for b0 in ([] if manual is not None else bones):
        b1 = best_child(b0)
        if not b1:
            continue
        b2 = best_child(b1)
        l0, l1 = b0.length, b1.length
        if min(l0, l1) < 0.06 * H:
            continue
        names = [b0.name, b1.name] + ([b2.name] if b2 else [])
        chord = b1.tail_local - b0.head_local
        if chord.length < 1e-6:
            continue
        vz = chord.normalized().dot(up)
        hh = (b0.head_local.dot(up) - hmin) / H
        kind = name_kind(names)
        if kind is None:
            if vz < -0.45 and hh < 0.65:
                kind = "LEG"
            elif hh >= 0.55 and vz < 0.6:
                kind = "ARM"
            else:
                continue
        score = min(l0, l1) / max(l0, l1)
        if b2 is None:
            score *= 0.4  # a chain without hand/foot is usually the real chain shifted one bone down
        elif b2.length > 1.4 * l1:
            score *= 0.5
        score *= role_factor(b0.name, b1.name)
        c = Limb()
        c.kind, c.b0, c.b1, c.b2, c.names = kind, b0, b1, b2, names
        c.score, c.total, c.side = score, l0 + l1, None
        cands.append(c)
    if manual is not None:
        cands = _manual_candidates(arm, manual)

    # greedy: pick disjoint chains with the best "limb-likeness"
    cands.sort(key=lambda c: (-c.score, -c.total))
    taken, accepted = set(), []
    for c in cands:
        if taken.isdisjoint(c.names):
            accepted.append(c)
            taken.update(c.names)
    cands = accepted

    # --- character "forward" direction ---
    rig.notes = []
    axes = {"-Y": (0, -1, 0), "+Y": (0, 1, 0), "-X": (-1, 0, 0), "+X": (1, 0, 0)}
    F, src = None, "default"
    if forward_mode in axes:
        F, src = w2a(axes[forward_mode]), "manual"
    else:
        legs = sorted((c for c in cands if c.kind == "LEG" and c.b2), key=lambda c: -c.total)[:2]
        dirs = [d for d in (_foot_direction(c.b2, up) for c in legs) if d]
        if dirs:
            acc = sum(dirs, Vector((0, 0, 0)))
            if acc.length >= 0.6 * len(dirs):
                F, src = acc.normalized(), "feet"
        if F is None:
            pos = {"L": [], "R": []}
            for c in cands:
                s = name_side(c.names)
                if s:
                    pos[s].append(c.b0.head_local)
            if pos["L"] and pos["R"]:
                lv = _flat(sum(pos["L"], Vector()) / len(pos["L"]) - sum(pos["R"], Vector()) / len(pos["R"]), up)
                if lv.length > 0.05 * H:
                    F, src = lv.normalized().cross(up), "L/R names"
        if F is None:
            F = w2a(axes["-Y"])
            rig.notes.append("Could not detect which way the character faces - assumed -Y. If bends are "
                             "reversed, pick the right direction in the 'Character Front' option.")
    F = _flat(F, up).normalized()
    rig.F, rig.fwd_src = F, src
    left_vec = up.cross(F)

    # --- body sides ---
    lat_mid = sum(b.head_local.dot(left_vec) for b in deform) / len(deform)
    groups = {}
    for c in cands:
        side = c.side or name_side(c.names)
        if side is None:
            side = "L" if c.b0.head_local.dot(left_vec) > lat_mid else "R"
        c.side = side
        groups.setdefault((c.kind, side), []).append(c)

    limbs = []
    for (kind, side), lst in groups.items():
        if manual is not None:
            limbs.extend(lst)  # the user decides: keep every picked limb
        else:
            limbs.append(max(lst, key=lambda c: (c.score >= 0.3, c.total)))
    limbs.sort(key=lambda c: (c.kind != "LEG", c.side))

    # --- details of every limb ---
    for l in limbs:
        b0, b1, b2 = l.b0, l.b1, l.b2
        l.root, l.mid, l.end = b0.head_local.copy(), b1.head_local.copy(), b1.tail_local.copy()
        chord = l.end - l.root
        a = chord.normalized()
        l.a, l.chord_len = a, chord.length
        m = l.mid - l.root
        off = m - a * m.dot(a)
        expected = _expected_bend(l.kind, a, F, up)
        rest_ok = off.length > 0.02 * l.total
        trusted = src != "default"
        if rest_ok:
            ob = off.normalized()
            if (not trusted) or ob.dot(expected) > 0.5:
                bend, l.bend_src = ob, "rest pose"
            else:
                bend, l.bend_src = expected, "anatomy"
        else:
            bend, l.bend_src = expected, "anatomy"
        bend = (bend - a * bend.dot(a)).normalized()
        l.bend = bend
        v0, v1 = l.mid - l.root, l.end - l.mid
        theta = v0.angle(v1) if v0.length > 1e-9 and v1.length > 1e-9 else 0.0
        l.rest_flex = theta if (not rest_ok or off.dot(bend) >= 0) else -theta
        # hinge axis of the lower bone (positive rotation about it = flexion)
        h = bend.cross(a).normalized()
        hl = b1.matrix_local.to_3x3().inverted() @ h
        l.hinge_axis = 0 if abs(hl.x) >= abs(hl.z) else 2
        comp = hl.x if l.hinge_axis == 0 else hl.z
        l.hinge_sign = 1 if comp >= 0 else -1
        l.hinge_ok = abs(comp) >= 0.9 * max(hl.length, 1e-9)
        l.hinge_local = hl.normalized()
        l.max_flex = math.radians(150.0)
        l.min_bend = math.radians(min_bend_deg)
        who = ("Left " if l.side == "L" else "Right ") + ("leg" if l.kind == "LEG" else "arm")
        l.label = who
        l.ctrl = IK_PREFIX + (b2.name if b2 else b1.name)
        l.pole = POLE_PREFIX + b1.name
        l.summary = "%s: %s > %s > %s | joint points: %s (%s)" % (
            who, b0.name, b1.name, b2.name if b2 else "-", _describe_dir(bend, rig), l.bend_src)
        l.b0, l.b1, l.b2 = b0.name, b1.name, (b2.name if b2 else None)
    rig.limbs = limbs
    return rig


# ---------------------------------------------------------------------------
# Helpers: removal, shapes, limits
# ---------------------------------------------------------------------------

def _set_mode(obj, mode):
    bpy.context.view_layer.objects.active = obj
    if obj.mode != mode:
        bpy.ops.object.mode_set(mode=mode)


def clear_limits(pb):
    for ch in "xyz":
        setattr(pb, "use_ik_limit_" + ch, False)
        setattr(pb, "lock_ik_" + ch, False)
        setattr(pb, "ik_min_" + ch, -math.pi)
        setattr(pb, "ik_max_" + ch, math.pi)


def apply_limits(pb, limb, flip=False):
    """Hinge for the lower bone (blocks knee/elbow from bending the wrong way)."""
    sign = limb.hinge_sign * (-1 if flip else 1)
    # Blender requires ik_min <= 0 <= ik_max, so a minimum bend cannot be expressed as a limit (hence apply_seed)
    lo = min(limb.min_bend - limb.rest_flex, 0.0)
    hi = max(limb.max_flex - limb.rest_flex, math.radians(10.0))
    mn, mx = (lo, hi) if sign > 0 else (-hi, -lo)
    for i, ch in enumerate("xyz"):
        if i == limb.hinge_axis:
            setattr(pb, "use_ik_limit_" + ch, True)
            setattr(pb, "ik_min_" + ch, mn)
            setattr(pb, "ik_max_" + ch, mx)
        else:
            setattr(pb, "lock_ik_" + ch, True)
    pb[PROP_LIM] = 1


def apply_seed(pb, limb, flip=False):
    """Pose-level 'pre-bend': Blender's IK solver cannot bend a perfectly straight chain (it sits in a
    singularity), so the lower bone gets a slight flexion as a starting point (rest pose is untouched)."""
    pb.rotation_mode = "QUATERNION"
    if limb.rest_flex < limb.min_bend:
        ang = max(limb.min_bend, math.radians(2.0)) * (-1 if flip else 1)
        q = Quaternion(limb.hinge_local, ang)
    else:
        q = Quaternion((1, 0, 0, 0))
    pb.rotation_quaternion = q
    pb[PROP_SEED] = list(q)


def reapply_seeds(obj):
    n = 0
    for pb in obj.pose.bones:
        q = pb.get(PROP_SEED)
        if q is not None:
            pb.rotation_mode = "QUATERNION"
            pb.rotation_quaternion = tuple(q)
            n += 1
    return n


def remove_generated(obj):
    """Removes bones, constraints, drivers and limits created by this add-on."""
    arm = obj.data
    _set_mode(obj, "POSE")
    names = []
    for pb in obj.pose.bones:
        for con in list(pb.constraints):
            if con.name.startswith(CON_IK) or con.name.startswith(CON_ROT):
                pb.constraints.remove(con)
        if pb.get(PROP_LIM):
            clear_limits(pb)
            pb.ik_stretch = 0.0
            del pb[PROP_LIM]
            if PROP_SEED in pb:
                del pb[PROP_SEED]
                pb.rotation_quaternion = (1, 0, 0, 0)
        if pb.get(PROP_TAG):
            names.append(pb.name)
    if obj.animation_data:
        for fc in list(obj.animation_data.drivers):
            if "NKIK" in fc.data_path:
                obj.animation_data.drivers.remove(fc)
    if names:
        _set_mode(obj, "EDIT")
        for n in names:
            eb = arm.edit_bones.get(n)
            if eb:
                arm.edit_bones.remove(eb)
        _set_mode(obj, "POSE")
    coll = arm.collections.get(COLLECTION_NAME)
    if coll is not None and len(coll.bones) == 0:
        arm.collections.remove(coll)
    return len(names)


def _shape_object(name, verts, edges):
    ob = bpy.data.objects.get(name)
    if ob is not None:
        return ob
    me = bpy.data.meshes.new(name)
    me.from_pydata(verts, edges, [])
    me.update()
    return bpy.data.objects.new(name, me)


def _box_shape():
    verts = [(x - 0.5, y, z - 0.5) for x in (0, 1) for y in (0, 1) for z in (0, 1)]
    edges = [(i, j) for i in range(8) for j in range(i + 1, 8) if bin(i ^ j).count("1") == 1]
    return _shape_object("NKIK_shape_box", verts, edges)


def _diamond_shape():
    verts = [(0.5, 0.5, 0), (0, 0.5, 0.5), (-0.5, 0.5, 0), (0, 0.5, -0.5), (0, 0, 0), (0, 1, 0)]
    edges = [(0, 1), (1, 2), (2, 3), (3, 0)] + [(i, t) for i in range(4) for t in (4, 5)]
    return _shape_object("NKIK_shape_diamond", verts, edges)


# ---------------------------------------------------------------------------
# Pole angle calibration by sampling the solver
# ---------------------------------------------------------------------------

def _eval_obj(obj):
    bpy.context.view_layer.update()
    return obj.evaluated_get(bpy.context.evaluated_depsgraph_get())


def _bend_vector(obj, limb):
    ev = _eval_obj(obj)
    pb = ev.pose.bones[limb.b1]
    mid, end = pb.head.copy(), pb.tail.copy()
    chord = end - limb.root
    if chord.length < 1e-9:
        return None
    c = chord.normalized()
    m = mid - limb.root
    return m - c * m.dot(c)


def _angle_error(obj, limb, con, angle):
    con.pole_angle = (angle + math.pi) % (2 * math.pi) - math.pi
    m = _bend_vector(obj, limb)
    if m is None or m.length < 1e-6 * limb.total:
        return math.pi
    return m.angle(limb.bend)


def calibrate_pole_angle(obj, limb, con):
    best = min(((_angle_error(obj, limb, con, math.radians(d)), math.radians(d)) for d in range(-180, 180, 15)))
    for step in (math.radians(3.0), math.radians(0.5)):
        center = best[1]
        cands = [(_angle_error(obj, limb, con, center + k * step), center + k * step) for k in range(-6, 7)]
        best = min(cands + [best])
    angle = (best[1] + math.pi) % (2 * math.pi) - math.pi
    con.pole_angle = angle
    return angle, _angle_error(obj, limb, con, angle)


def rest_twist(obj, limb, ctrl_pb):
    """Largest rotation (rad) of the upper/lower bone from rest pose while the control stays in place."""
    ctrl_pb.location = (0, 0, 0)
    ev = _eval_obj(obj)
    worst = 0.0
    for n in (limb.b0, limb.b1):
        rest = obj.data.bones[n].matrix_local.to_3x3()
        cur = ev.pose.bones[n].matrix.to_3x3()
        worst = max(worst, (cur @ rest.inverted()).to_quaternion().angle)
    return worst


def refine_for_rest(obj, limb, con, ctrl_pb, angle):
    """Among angles that still give the correct bend direction (<1 deg), picks the one with the
    least bone twist in the rest pose."""
    best = None
    for k in range(-10, 11):
        a = angle + math.radians(k * 0.5)
        _shift_ctrl(obj, limb, ctrl_pb)
        if _angle_error(obj, limb, con, a) > math.radians(1.0):
            continue
        twist = rest_twist(obj, limb, ctrl_pb)
        if best is None or twist < best[0]:
            best = (twist, a)
    a = angle if best is None else best[1]
    con.pole_angle = (a + math.pi) % (2 * math.pi) - math.pi
    return con.pole_angle


def rest_deviation(obj, limb, ctrl_pb):
    ctrl_pb.location = (0, 0, 0)
    ev = _eval_obj(obj)
    pb = ev.pose.bones[limb.b1]
    dev = max((pb.head - limb.mid).length, (pb.tail - limb.end).length)
    return dev / limb.total


def _shift_ctrl(obj, limb, ctrl_pb, frac=0.3):
    delta = -limb.a * (frac * limb.chord_len)
    rot = obj.data.bones[ctrl_pb.name].matrix_local.to_3x3()
    ctrl_pb.location = rot.inverted() @ delta


# ---------------------------------------------------------------------------
# Main IK builder
# ---------------------------------------------------------------------------

def find_control_parent(obj, limbs, rig):
    arm = obj.data
    tops = set()
    for l in limbs:
        b = arm.bones[l.b0]
        while b.parent:
            b = b.parent
        tops.add(b.name)
    if len(tops) != 1:
        return None
    top = arm.bones[tops.pop()]
    if top.name in {l.b0 for l in limbs}:
        return None
    rootlike = bool(set(_tokens(top.name)) & ROOT_TOKENS)
    low = (top.head_local.dot(rig.up) - rig.hmin) < 0.06 * rig.H
    if rootlike or low or not top.use_deform:
        return top.name
    return None


def create_ik(obj, rig, limbs, s):
    arm = obj.data
    log = []
    parent_name = find_control_parent(obj, limbs, rig) if s.parent_mode == "AUTO" else None

    # ---- control bones (edit mode) ----
    _set_mode(obj, "EDIT")
    ebs = arm.edit_bones
    for l in limbs:
        b1e = ebs[l.b1]
        b2e = ebs[l.b2] if l.b2 else None
        ctrl = ebs.new(l.ctrl)
        ctrl.head = l.end
        if b2e:
            ctrl.tail = l.end + (b2e.tail - b2e.head)
            ctrl.roll = b2e.roll
        else:
            ctrl.tail = l.end + l.a * (0.1 * l.total)
            ctrl.roll = b1e.roll
        pole_pos = l.mid + l.bend * (s.pole_dist * l.total)
        pole = ebs.new(l.pole)
        pole.head = pole_pos
        pole.tail = pole_pos + l.bend * (0.12 * l.total)
        for eb in (ctrl, pole):
            eb.use_deform = False
            eb.use_connect = False
            if parent_name:
                eb.parent = ebs[parent_name]
        l.ctrl, l.pole = ctrl.name, pole.name

    # ---- constraints (pose mode) ----
    _set_mode(obj, "POSE")
    coll = arm.collections.get(COLLECTION_NAME) or arm.collections.new(COLLECTION_NAME)
    box, diamond = (_box_shape(), _diamond_shape()) if s.shapes else (None, None)
    palette = {"L": "THEME04", "R": "THEME01"}

    for l in limbs:
        pose = obj.pose.bones
        pc1 = pose[l.b1]
        pc2 = pose[l.b2] if l.b2 else None
        ctrl_pb, pole_pb = pose[l.ctrl], pose[l.pole]

        for pb, shape in ((ctrl_pb, box), (pole_pb, diamond)):
            pb[PROP_TAG] = 1
            if shape is not None:
                pb.custom_shape = shape
            try:
                pb.color.palette = palette[l.side]
            except Exception:
                pass
            coll.assign(arm.bones[pb.name])
        pole_pb.lock_rotation = (True, True, True)

        for con in list(pc1.constraints):
            if con.type == "IK":
                pc1.constraints.remove(con)
        con = pc1.constraints.new("IK")
        con.name = CON_IK
        con.target, con.subtarget = obj, l.ctrl
        con.pole_target, con.pole_subtarget = obj, l.pole
        con.chain_count = 2
        con.use_tail = True
        con.use_stretch = s.stretch > 0.0
        pc1.ik_stretch = s.stretch
        pc1[PROP_LIM] = 1

        # --- settings choice: hinge limits + pole angle, with automatic verification ---
        attempts = [False, True] if (s.auto_limits and l.hinge_ok) else []
        attempts.append(None)
        results = []
        for att in attempts:
            clear_limits(pc1)
            apply_seed(pc1, l, flip=bool(att))
            if att is not None:
                apply_limits(pc1, l, flip=att)
            _shift_ctrl(obj, l, ctrl_pb)
            angle, err = calibrate_pole_angle(obj, l, con)
            _shift_ctrl(obj, l, ctrl_pb)
            angle = refine_for_rest(obj, l, con, ctrl_pb, angle)
            _shift_ctrl(obj, l, ctrl_pb)
            err = _angle_error(obj, l, con, angle)
            dev = rest_deviation(obj, l, ctrl_pb)
            results.append((math.degrees(err) + 100.0 * dev, att, angle, err, dev))
            if err < math.radians(8.0) and dev < 0.04:
                break
        cost, att, angle, err, dev = min(results, key=lambda r: r[0])
        clear_limits(pc1)
        apply_seed(pc1, l, flip=bool(att))
        if att is not None:
            apply_limits(pc1, l, flip=att)
        con.pole_angle = angle
        ctrl_pb.location = (0, 0, 0)

        if pc2 is not None:
            cr = pc2.constraints.new("COPY_ROTATION")
            cr.name = CON_ROT
            cr.target, cr.subtarget = obj, l.ctrl
            cr.target_space = cr.owner_space = "WORLD"

        if s.ikfk:
            ctrl_pb[PROP_SWITCH] = 1.0
            ctrl_pb.id_properties_ui(PROP_SWITCH).update(min=0.0, max=1.0, description="1 = IK, 0 = FK")
            for c in [con] + ([cr] if pc2 is not None else []):
                fc = c.driver_add("influence")
                d = fc.driver
                d.type = "SUM"
                var = d.variables.new()
                var.name = "ik"
                var.type = "SINGLE_PROP"
                var.targets[0].id = obj
                var.targets[0].data_path = 'pose.bones["%s"]["%s"]' % (l.ctrl, PROP_SWITCH)

        mode_txt = "hinge limits" if att is not None else "no limits (pre-bend)"
        line = "%s: pole angle %.1f deg, bend direction error %.1f deg, rest deviation %.1f%%, %s" % (
            l.label, math.degrees(angle), math.degrees(err), dev * 100.0, mode_txt)
        if err > math.radians(15.0):
            line += "  [WARNING: check the bend direction manually]"
        log.append(line)

    _set_mode(obj, "POSE")
    return log


# ---------------------------------------------------------------------------
# Operators and UI
# ---------------------------------------------------------------------------

class NKIKManualLimb(bpy.types.PropertyGroup):
    kind: EnumProperty(name="Type", items=[("LEG", "Leg", ""), ("ARM", "Arm", "")], default="LEG")
    side: EnumProperty(name="Side", items=[("L", "Left", ""), ("R", "Right", "")], default="L")
    upper: StringProperty(name="Upper", description="Thigh / upper arm bone")
    lower: StringProperty(name="Lower", description="Shin / forearm bone (the IK constraint goes here)")
    end: StringProperty(name="End", description="Foot / hand bone (optional); follows the IK control rotation")


class NKIKSettings(bpy.types.PropertyGroup):
    do_arms: BoolProperty(name="Arms", default=True)
    do_legs: BoolProperty(name="Legs", default=True)
    use_manual: BoolProperty(
        name="Pick Bones Manually", default=False,
        description="Use the bones listed below instead of automatic detection")
    manual: CollectionProperty(type=NKIKManualLimb)
    forward: EnumProperty(
        name="Character Front",
        description="World axis the character faces; Auto detects it from the feet",
        items=[("AUTO", "Auto", "Detect from feet / names"), ("-Y", "-Y", ""), ("+Y", "+Y", ""),
               ("-X", "-X", ""), ("+X", "+X", "")],
        default="AUTO")
    pole_dist: FloatProperty(name="Pole Distance", description="Multiple of the limb length",
                             default=0.7, min=0.2, max=3.0)
    auto_limits: BoolProperty(name="Joint Limits", default=True,
                              description="Locks knees/elbows as a hinge that bends in one direction only")
    min_bend: FloatProperty(name="Minimum Bend (deg)", default=2.0, min=0.0, max=20.0,
                            description="Degrees. Straight limbs need a slight bend, otherwise Blender's IK "
                                        "refuses to bend them")
    stretch: FloatProperty(name="IK Stretch", default=0.0, min=0.0, max=1.0)
    shapes: BoolProperty(name="Control Shapes", default=True)
    ikfk: BoolProperty(name="IK/FK Switch", default=True,
                       description="Adds an 'IK' property on the control (1 = IK, 0 = FK) driving the constraints")
    parent_mode: EnumProperty(name="Control Parent",
                              items=[("AUTO", "Auto", "Parent controls to the root bone if the rig has one"),
                                     ("NONE", "None", "Controls have no parent")],
                              default="AUTO")
    report: StringProperty(default="")


def _active_armature(context):
    ob = context.active_object
    return ob if ob is not None and ob.type == "ARMATURE" else None


def _manual_list(s):
    return [{"kind": m.kind, "side": m.side, "upper": m.upper, "lower": m.lower, "end": m.end} for m in s.manual]


def _run_analysis(obj, s):
    if s.use_manual:
        if not s.manual:
            raise ValueError("Add at least one limb to the manual list.")
        return analyze(obj, s.forward, s.min_bend, manual=_manual_list(s))
    return analyze(obj, s.forward, s.min_bend)


def _fwd_line(rig):
    return "Character front: %s (source: %s)" % (_describe_dir(rig.F, rig), rig.fwd_src)


class NKIK_OT_analyze(bpy.types.Operator):
    bl_idname = "nkik.analyze"
    bl_label = "Detect Limbs"
    bl_description = "Analyzes the armature and shows the limbs and bend directions that would be used (changes nothing)"

    @classmethod
    def poll(cls, context):
        return _active_armature(context) is not None

    def execute(self, context):
        s = context.scene.nkik
        obj = context.active_object
        try:
            rig = _run_analysis(obj, s)
        except ValueError as e:
            self.report({"ERROR"}, str(e))
            return {"CANCELLED"}
        lines = [_fwd_line(rig)]
        lines += [l.summary for l in rig.limbs] or ["No limbs detected."]
        lines += rig.notes
        s.report = "\n".join(lines)
        return {"FINISHED"}


class NKIK_OT_create(bpy.types.Operator):
    bl_idname = "nkik.create"
    bl_label = "Create IK"
    bl_description = "Creates IK controls and pole targets with automatically chosen settings"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return _active_armature(context) is not None

    def execute(self, context):
        s = context.scene.nkik
        obj = context.active_object
        try:
            if obj.mode != "OBJECT":
                bpy.ops.object.mode_set(mode="OBJECT")
            remove_generated(obj)
            rig = _run_analysis(obj, s)
            limbs = rig.limbs if s.use_manual else [
                l for l in rig.limbs if (l.kind == "ARM" and s.do_arms) or (l.kind == "LEG" and s.do_legs)]
            if not limbs:
                self.report({"ERROR"}, "No limbs found to build IK for.")
                return {"CANCELLED"}
            log = create_ik(obj, rig, limbs, s)
        except ValueError as e:
            self.report({"ERROR"}, str(e))
            return {"CANCELLED"}
        except Exception as e:  # noqa: BLE001
            self.report({"ERROR"}, "Error: %s" % e)
            raise
        lines = [_fwd_line(rig)]
        lines += [l.summary for l in limbs] + log + rig.notes
        s.report = "\n".join(lines)
        self.report({"INFO"}, "Created IK for %d limbs." % len(limbs))
        return {"FINISHED"}


class NKIK_OT_remove(bpy.types.Operator):
    bl_idname = "nkik.remove"
    bl_label = "Remove Generated IK"
    bl_description = "Removes the controls, constraints and limits created by this add-on"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return _active_armature(context) is not None

    def execute(self, context):
        obj = context.active_object
        if obj.mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
        n = remove_generated(obj)
        context.scene.nkik.report = ""
        _set_mode(obj, "POSE")
        self.report({"INFO"}, "Removed %d control bones." % n)
        return {"FINISHED"}


class NKIK_OT_prebend(bpy.types.Operator):
    bl_idname = "nkik.prebend"
    bl_label = "Restore Pre-bend"
    bl_description = ("Restores the slight knee/elbow bend used as the IK starting point "
                      "(use it if a limb stopped bending after clearing transforms)")
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return _active_armature(context) is not None

    def execute(self, context):
        obj = context.active_object
        _set_mode(obj, "POSE")
        self.report({"INFO"}, "Restored pre-bend on %d bones." % reapply_seeds(obj))
        return {"FINISHED"}


def _guess_kind_side(arm, b0, obj):
    kind = name_kind([b0.name])
    world_z = [(obj.matrix_world @ b.head_local).z for b in arm.bones]
    if kind is None:
        mid_z = (min(world_z) + max(world_z)) / 2
        kind = "LEG" if (obj.matrix_world @ b0.head_local).z < mid_z else "ARM"
    side = name_side([b0.name]) or ("L" if (obj.matrix_world @ b0.head_local).x > 0 else "R")
    return kind, side


class NKIK_OT_manual_add(bpy.types.Operator):
    bl_idname = "nkik.manual_add"
    bl_label = "Add Limb"
    bl_description = ("Adds a manual limb. If 2-3 connected parent>child bones are selected "
                      "they are used to fill Upper / Lower / End")
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return _active_armature(context) is not None

    def execute(self, context):
        obj = context.active_object
        arm = obj.data
        s = context.scene.nkik
        m = s.manual.add()
        sel = [b for b in arm.bones if b.select]

        def depth(b):
            d = 0
            while b.parent:
                b, d = b.parent, d + 1
            return d

        sel.sort(key=depth)
        chain_ok = 2 <= len(sel) <= 3 and all(
            sel[i + 1].parent is not None and sel[i + 1].parent.name == sel[i].name for i in range(len(sel) - 1))
        if chain_ok:
            m.upper, m.lower = sel[0].name, sel[1].name
            m.end = sel[2].name if len(sel) == 3 else ""
            m.kind, m.side = _guess_kind_side(arm, sel[0], obj)
        elif sel:
            self.report({"WARNING"}, "Selected bones are not a 2-3 bone parent>child chain; pick bones in the list.")
        s.use_manual = True
        return {"FINISHED"}


class NKIK_OT_manual_remove(bpy.types.Operator):
    bl_idname = "nkik.manual_remove"
    bl_label = "Remove Limb"
    bl_options = {"REGISTER", "UNDO"}

    index: IntProperty()

    def execute(self, context):
        context.scene.nkik.manual.remove(self.index)
        return {"FINISHED"}


class NKIK_OT_manual_fill(bpy.types.Operator):
    bl_idname = "nkik.manual_fill"
    bl_label = "Fill From Detection"
    bl_description = "Replaces the manual list with the automatically detected limbs, so you can correct them"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return _active_armature(context) is not None

    def execute(self, context):
        s = context.scene.nkik
        try:
            rig = analyze(context.active_object, s.forward, s.min_bend)
        except ValueError as e:
            self.report({"ERROR"}, str(e))
            return {"CANCELLED"}
        s.manual.clear()
        for l in rig.limbs:
            m = s.manual.add()
            m.kind, m.side, m.upper, m.lower, m.end = l.kind, l.side, l.b0, l.b1, l.b2 or ""
        s.use_manual = True
        return {"FINISHED"}


class NKIK_PT_main(bpy.types.Panel):
    bl_label = "NK Auto IK"
    bl_idname = "NKIK_PT_main"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "NK IK"

    def draw(self, context):
        layout = self.layout
        s = context.scene.nkik
        ob = _active_armature(context)
        if ob is None:
            layout.label(text="Select an armature", icon="INFO")
            return
        layout.label(text=ob.name, icon="ARMATURE_DATA")
        if not s.use_manual:
            row = layout.row(align=True)
            row.prop(s, "do_legs", toggle=True)
            row.prop(s, "do_arms", toggle=True)
        layout.operator("nkik.analyze", icon="VIEWZOOM")
        layout.operator("nkik.create", icon="CON_KINEMATIC")
        layout.operator("nkik.prebend", icon="LOOP_BACK")
        layout.operator("nkik.remove", icon="TRASH")

        box = layout.box()
        box.prop(s, "use_manual")
        if s.use_manual:
            row = box.row(align=True)
            row.operator("nkik.manual_add", icon="ADD")
            row.operator("nkik.manual_fill", icon="FILE_REFRESH")
            for i, m in enumerate(s.manual):
                col = box.box().column(align=True)
                row = col.row(align=True)
                row.prop(m, "kind", text="")
                row.prop(m, "side", text="")
                row.operator("nkik.manual_remove", text="", icon="X").index = i
                col.prop_search(m, "upper", ob.data, "bones", text="Upper")
                col.prop_search(m, "lower", ob.data, "bones", text="Lower")
                col.prop_search(m, "end", ob.data, "bones", text="End")

        box = layout.box()
        box.label(text="Options")
        box.prop(s, "forward")
        box.prop(s, "pole_dist")
        box.prop(s, "auto_limits")
        box.prop(s, "min_bend")
        box.prop(s, "stretch")
        box.prop(s, "ikfk")
        box.prop(s, "shapes")
        box.prop(s, "parent_mode")

        if s.report:
            box = layout.box()
            for line in s.report.split("\n"):
                box.label(text=line)


classes = (NKIKManualLimb, NKIKSettings, NKIK_OT_analyze, NKIK_OT_create, NKIK_OT_remove, NKIK_OT_prebend,
           NKIK_OT_manual_add, NKIK_OT_manual_remove, NKIK_OT_manual_fill, NKIK_PT_main)


def register():
    for c in classes:
        bpy.utils.register_class(c)
    bpy.types.Scene.nkik = PointerProperty(type=NKIKSettings)


def unregister():
    del bpy.types.Scene.nkik
    for c in reversed(classes):
        bpy.utils.unregister_class(c)


if __name__ == "__main__":
    register()
